# Return by Death Totem

A client-side Fabric mod project for Minecraft 26.3. It attempts to play the supplied Return by Death audio when the local player's Totem of Undying activation event is received.

## Build online with GitHub Actions

This project includes `.github/workflows/build.yml`. Upload the *contents* of this folder to a GitHub repository (not just this ZIP), then open the repository's **Actions** tab. The workflow runs on a push to `main`/`master`, or can be started using **Run workflow**. If the build succeeds, download the `ReturnByDeathTotem-JAR` artifact from the workflow run.

## Important

This is source code, not a compiled or tested JAR. The build may reveal Minecraft 26.3 API or mixin issues that need correction. A successful build is not a substitute for testing in a separate Modrinth profile.
