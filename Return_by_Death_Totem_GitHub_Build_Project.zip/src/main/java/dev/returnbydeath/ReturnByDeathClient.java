package dev.returnbydeath;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
public class ReturnByDeathClient implements ClientModInitializer {
 public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("return_by_death_totem","return_by_death");
 public static final SoundEvent SOUND = SoundEvent.createVariableRangeEvent(ID);
 public void onInitializeClient() { Registry.register(BuiltInRegistries.SOUND_EVENT, ID, SOUND); }
}