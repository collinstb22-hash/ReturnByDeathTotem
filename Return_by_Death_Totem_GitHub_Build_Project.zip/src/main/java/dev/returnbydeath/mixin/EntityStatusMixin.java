package dev.returnbydeath.mixin;
import dev.returnbydeath.ReturnByDeathClient;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Entity.class)
public abstract class EntityStatusMixin {
 @Inject(method="handleEntityEvent", at=@At("HEAD"))
 private void returnByDeath$totem(byte status, CallbackInfo ci) {
  if(status != 35) return;
  Entity e=(Entity)(Object)this; Minecraft mc=Minecraft.getInstance();
  if(mc.player != null && e == mc.player && mc.level != null)
   mc.level.playLocalSound(e.getX(),e.getY(),e.getZ(),ReturnByDeathClient.SOUND,net.minecraft.sounds.SoundSource.PLAYERS,1.0F,1.0F,false);
 }
}